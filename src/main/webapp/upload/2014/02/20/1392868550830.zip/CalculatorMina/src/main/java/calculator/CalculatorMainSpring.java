package calculator;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CalculatorMainSpring {

	public static void main(String[] args) {
		new ClassPathXmlApplicationContext("context.xml");
	} 
}
